<?php


Class Public_page_model Extends CI_Model 
{
    function __construct() 
    {
		parent::__construct();
        $this->load->database(); 
	}
      

	function getHotelList($searchdata)
	{	
        $script1=" SELECT  * from  hotels " ;
        if(!($searchdata==""||$searchdata=="0"))
        {
            $script1=$script1 . " where location like '%". $searchdata ."%' ";
        }
        
        
        $script1=$script1 . " order by hotel_name " ;
        $rec = $this->db->query($script1);  

        if($rec->num_rows() > 0) 
			$return=$rec ;
		else 
			$return='No';             
        return $return;
    }
    function getRoomsListFull($searchdata)
	{	
        $script1=" SELECT rooms.*,hotels.`hotel_name`,hotels.`location` FROM rooms INNER JOIN hotels ON hotels.`hotel_id`=rooms.`hotel_id` " ;

        if(!($searchdata==""||$searchdata=="0"))
        {
            $script1=$script1 . " where hotel_id =". $searchdata ." ";
        }        
        
        $script1=$script1 . " order by location,hotel_name,room_number " ;
        $rec = $this->db->query($script1);  

        if($rec->num_rows() > 0) 
			$return=$rec ;
		else 
			$return='No';             
        return $return;
    }

    function getGuestList($searchdata)
	{	
        $script1=" SELECT  * from  client_users " ; 
        $script1=$script1 . " order by client_id " ;
        $rec = $this->db->query($script1);  

        if($rec->num_rows() > 0) 
			$return=$rec ;
		else 
			$return='No';             
        return $return;
    }

    function getHotelDetails($searchdata)
	{	
        //$EnterpriseID = $this->session->userdata['mysession']['enterprise_id'];
        //$UserId = $this->session->userdata['mysession']['user_id'];

        $script1=" SELECT  * from  hotels " ;
        if(!($searchdata==""||$searchdata=="0"))
        {
            $script1=$script1 . " where hotel_id =". $searchdata ."";
        }
        else
        {
            $script1=$script1 . " where hotel_id =0";
        }
        
        
        $script1=$script1 . " order by hotel_name " ;
        $rec = $this->db->query($script1);  
 
        if($rec->num_rows() > 0) 
			$return=$rec ;
		else 
			$return='No';             
        return $return;
    }

	function getRoomsList($searchdata,$datefrom,$dateto)
	{	
       
        $datefrom=date("Y-m-d", strtotime($datefrom));
        $dateto=date("Y-m-d", strtotime($dateto));
        $script1= "SELECT room_id,hotel_id,room_number,facilities,room_type,no_of_adults,no_of_childs,image1,COUNT(availability_date) available, IFNULL(SUM(rate),0) rate,IFNULL(SUM(tax_amount),0) tax,IFNULL(SUM(total_amount),0) total_amount,  ";
        $script1= $script1 . ' IFNULL( DATEDIFF("'.$dateto.'", "'.$datefrom.'")+1,0) days, IFNULL( (DATEDIFF("'.$dateto.'", "'.$datefrom.'")+1)-COUNT(availability_date),0) AS diff ';
        $script1= $script1 . " FROM( ";
        $script1= $script1 . " SELECT r.*,a.`availability_date`,a.rate,a.`tax_amount`,a.`total_amount`,a.`status_id` AS astatus_id, CASE a.`status_id` WHEN 1 THEN 'Available' ELSE 'Not Available' END AS status_lable FROM rooms r ";
        $script1= $script1 . ' LEFT JOIN room_availability_rate a ON r.`room_id` = a.`room_id` AND a.`availability_date` BETWEEN "'.$datefrom.'" AND "'.$dateto.'"  AND a.`status_id`=1 ';
        $script1= $script1 . ' WHERE r.hotel_id = '.$searchdata.' AND r.status_id=1 ' ;
        $script1= $script1 . " ) X ";
        $script1= $script1 . " GROUP BY room_id,hotel_id,room_number,facilities,room_type,no_of_adults,no_of_childs,image1,astatus_id ";
        $script1=$script1 . " order by room_number " ;
        $rec = $this->db->query($script1);  

        if($rec->num_rows() > 0) 
			$return=$rec ;
		else 
			$return='No';             
        return $return;
    }

    function getLocation()
	{	         
        $script2 = " SELECT DISTINCT location FROM hotels" ;
        $rec = $this->db->query($script2);   
 
        if($rec->num_rows() > 0) 
        {
           $return['0'] = "All";
           foreach($rec->result_array() as $row)
		   { $return[$row['location']] = $row['location']; }
        }
		else 
		$return['0'] = "---";
            
        return $return;
    }
    function getRoomsCount()
	{
		$return['0'] = "...";
		$return['1'] = "1";
        $return['2'] = "2"; 
        $return['3'] = "3";
		return $return;
    }
    function bookRoom($room_id,$hotel_id,$from_date,$to_date)
    {
        $user_id = $this->session->userdata['mysession']['client_id']; 
        $rec="0";
        If(!empty($user_id))
        {        
            $random_number=rand(1000000000,10000000000);
            $script2=" INSERT INTO booking (booking_number,booking_date,client_id,hotel_id,booking_mode,transaction_details,total_rate,total_tax,total_amount,status_id)	 " ;
            $script2 = $script2 . " SELECT booking_number,booking_date,client_id,hotel_id,booking_mode,transaction_details,total_rate,total_tax,total_amount,status_id FROM " ;
            $script2 = $script2 . " (SELECT ".$random_number." booking_number,CURDATE() booking_date,1 client_id,hotel_id,'Online' AS booking_mode,room_number transaction_details, IFNULL(SUM(rate),0) total_rate,IFNULL(SUM(tax_amount),0) total_tax,IFNULL(SUM(total_amount),0) total_amount, 1 status_id  " ;
            $script2 = $script2 . " ,IFNULL( (DATEDIFF(".$to_date.", ".$from_date.")+1)-COUNT(availability_date),0) AS diff          " ;
            $script2 = $script2 . "      FROM(  " ;
            $script2 = $script2 . "      SELECT r.*,a.`availability_date`,a.rate,a.`tax_amount`,a.`total_amount`,a.`status_id` AS astatus_id, CASE a.`status_id` WHEN 1 THEN 'Available' ELSE 'Not Available' END AS status_lable FROM rooms r  " ;
            $script2 = $script2 . "      LEFT JOIN room_availability_rate a ON r.`room_id` = a.`room_id` AND a.`availability_date` BETWEEN ".$from_date." AND ".$to_date."  AND a.`status_id`=1  " ;
            $script2 = $script2 . "      WHERE r.hotel_id = ".$hotel_id." AND  r.room_id = ".$room_id." AND r.status_id=1   " ;
            $script2 = $script2 . "      ) X  " ;
            $script2 = $script2 . "      GROUP BY room_id,hotel_id,room_number,facilities,room_type,no_of_adults,no_of_childs,image1,astatus_id  " ;
            $script2 = $script2 . "      HAVING diff=0 " ;
            $script2 = $script2 . "     )X	 " ;
            echo $script2;
            $rec = $this->db->query($script2);
            
            $script3=" INSERT INTO booking_transaction (booking_id,hotel_id,room_id,room_availability_id,rate,tax_amount,total_amount,status_id)  " ;
            $script3 = $script3 . "   SELECT * FROM   " ;
            $script3 = $script3 . "   (SELECT booking_id FROM booking b WHERE booking_number=".$random_number.") q1 JOIN 	  " ;
            $script3 = $script3 . "   (SELECT r.hotel_id,r.room_id,a.availability_id,a.rate,a.`tax_amount`,a.`total_amount`,1 AS status_id FROM rooms r   " ;
            $script3 = $script3 . "   LEFT JOIN room_availability_rate a ON r.`room_id` = a.`room_id` AND a.`availability_date` BETWEEN ".$from_date." AND ".$to_date."  AND a.`status_id`=1   " ;
            $script3 = $script3 . "   WHERE r.hotel_id = ".$hotel_id." AND  r.room_id = ".$room_id." AND r.status_id=1  ) q2  " ;
            echo $script3;
            $rec = $this->db->query($script3);
            $rec =1;
        }

        //$rec = 1;
        
        return $rec ; 
    }
}
?>