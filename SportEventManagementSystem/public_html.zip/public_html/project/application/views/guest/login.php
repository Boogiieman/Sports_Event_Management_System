<div class="middle-box text-center loginscreen  animated fadeInDown">
        <div><br>
            <div>
                <h1 class="logo-name">HB+</h1>
            </div>
            <h3>Welcome to Hotel Booking System</h3>
            <p>Login for Guest </p>            
            <form class="m-t" role="form" action="<?php echo base_url(); ?>index.php/public_page/hotels" name="form1" id="form1">
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Username" required="" name="txtemail" id="txtemail">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" required="" name="txtpassword" id="txtpassword">
                </div>
                <button type="button" name="cmdlogin" id="cmdlogin" class="btn btn-primary block full-width m-b">Login</button>

                <a href="<?php echo base_url(); ?>index.php/guest/forgotpassword"><small>Forgot password?</small></a>
                <p class="text-muted text-center"><small>Do not have an account?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="<?php echo base_url(); ?>index.php/guest/register">Create an account</a>
            </form>
            <p class="m-t"> <small>Project Work - BCA Degree - University of Kerala  &copy; 2020</small> </p>
            
        </div>
    </div>
    <script>
    $(document).ready(function()
    {
        $('#cmdlogin').click(function (event)
        {             
                var serializedData = $('#form1').serialize();                
                $.ajax({
                    type:"POST",
                    dataType: "json",
                    data: serializedData,
                    url:"<?php echo base_url(); ?>index.php/guest/logincheck",                                    
                    success:function(data)
                    {
                        alert(data.msg);
                        if(data.Success==1)
                        {
                            $('#form1').submit()  
                        }
                    },
                    error: function(jqXHR, textStatus, errorThrown) 
                    {  
                        $("#msg").html("ERROR:::::" + jqXHR.responseText);
                        alert("error:" + jqXHR.responseText);	
                    }
                });
     
        });
    });
    </script>