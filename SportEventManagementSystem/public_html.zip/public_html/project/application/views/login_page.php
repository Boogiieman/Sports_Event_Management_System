<!DOCTYPE html>
<html>
<script src="<?php echo base_url(); ?>assets/js/jquery-2.1.1.js"></script>  
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Hotel Booking System Ver.1.0</title>

    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="<?php echo base_url(); ?>assets/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">
<div id="page-wrapper" class="gray-bg">
    <div class="loginColumns animated fadeInDown">
    	<div class="row">
            <div class="col-md-12" align="center">
            		<h2 class="font-bold">Welcome to Hotel Booking System</h2>
            </div>
         </div>  
         <hr/> 
        <?php 
			$attr1= array('name' => 'frmLogin', 'id' => 'frmLogin');
			echo form_open('#',$attr1);
		?>
        <div class="row">
        	<div class="col-md-6">
                <div class="ibox-content">
                    <form class="m-t" role="form" action="<?php echo base_url(); ?>index.php/welcome/login">
                        <div class="form-group">
                            <input type="text" id="key_n" name="key_n"  class="form-control" placeholder="User Name" required="">
                        </div>
                        <div class="form-group">
                            <input  type="password" id="key_p" name="key_p" class="form-control" placeholder="Password" required="" >
                        </div>
                        <button id="cmdLogin" type="submit" class="btn btn-primary block full-width m-b">Login</button>
                        
                        <p class="text-muted text-center">
                            <small><div id="LoginMsg" class="modal-body" style="color: skyblue;text-align: center;" ></div></small>
                        </p>
                        
                        <a href="#">
                            <small>Forgot password?</small>
                        </a>

                        <p class="text-muted text-center">
                            <small>Do not have an account? Please contact your Admin</small>
                        </p>
                        <a href="<?php echo base_url(); ?>index.php/public_page">
                            <small>Public Module</small>
                        </a>
                    </form>
                    <p class="m-t  text-center">
                        <small>Application Software &copy; 2019-2020</small>
                    </p>
                </div>
            </div>        	
            <div class="col-md-6" align="left">
                <p>
                    Please enter your login credentials provided by your Admin.
                </p>

                <p>
                    This product is maintained in the name of Application Software
                </p>
                <p>
                    <small>For support please send email to <b>xxx@gmail.com</b> </small>
                </p>

            </div>
	  	<?php
			echo form_close();
		?>            
            
        </div>
        <hr/>
        <div class="row">
            <div class="col-md-6">
                Copyright Hotel Booking System Ver.1.0
            </div>
            <div class="col-md-6 text-right">
               <small>© 2019-2020</small>
            </div>
        </div>
    </div>
</div>
</body>

</html>

<script>

	$(document).ready(function(){
		
		$('#LoginMsg').html('');
		$("#cmdLogin").click(function(event){ 
			event.preventDefault();
			var values = $("#frmLogin").serialize();
			$.ajax({
				type:"POST",
				url:"<?php echo base_url(); ?>index.php/Main/login",
				data: values,
			    dataType: "json",
				success:function(data)
				{ 
					$('#LoginMsg').html(data.msg);  
					if(data.flag==1 )
					{
					    location.reload(); 
					} 
				},
                error: function(jqXHR, textStatus, errorThrown) 
    		   { 
    			  $("#LoginMsg").html(jqXHR.responseText); 
    		   }
			});

		});

	});

</script>