<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Public_page extends CI_Controller {
    function __construct()
    {
		parent::__construct();
		$this->load->database();
		date_default_timezone_set( 'Asia/Kolkata' ); 
		$this->load->model("public_page_model","PPmo");
    }

	public function index()
	{
        //$Data['masters']="";        
		//$this->loadView('public/public_page_statistics',$Data);
		$this->hotels();
    } 
    public function hospitals()
	{
        $Data['masters']="";        
        $this->loadView('public/public_page_hospitals',$Data);
	}
	public function hotels()
	{
		$searchdata=$this->input->post('txtLocation');
		$datefrom=$this->input->post('datefrom');
		if(!isset($datefrom)) {$datefrom=date('m-d-Y');}
		$dateto=$this->input->post('dateto');		
		if(!isset($dateto)) 
		{
			$stop_date = new DateTime(date('Y-m-d')); 
			$stop_date->modify('+2 day');
			$dateto=$stop_date->format('m-d-Y');
		}
		$Data['lstlocation']=   $this->PPmo->getLocation();
		$Data['location']=   $this->input->post('txtLocation');
		$Data['lstRooms']=   $this->PPmo->getRoomsCount();
		$Data['rooms']=   $this->input->post('txtrooms');		
		$Data['datefrom']=$datefrom;
		$Data['dateto']=$dateto;
		$Data['searchdata']=$searchdata;
		$Data['v_data']= $this->PPmo->getHotelList($searchdata);
        $Data['masters']="";        
        $this->loadView('public/public_page_hotels',$Data);
	} 
	public function rooms()
	{
		//$UserName = $this->session->userdata['mysession']['user_name'];

		$searchdata=$this->input->post('hotel_id');
		$datefrom=$this->input->post('vdatefrom');
		if(!isset($datefrom)) {$datefrom=date('m-d-Y');}
		$dateto=$this->input->post('vdateto');		
		if(!isset($dateto)) 
		{
			$stop_date = new DateTime(date('Y-m-d')); 
			$stop_date->modify('+2 day');
			$dateto=$stop_date->format('m-d-Y');
			echo '~'.$datefrom . '~' . $dateto ;
		}
		//$Data['UserName']=   $UserName;
		$Data['lstRooms']=   $this->PPmo->getRoomsCount();
		$Data['rooms']=   $this->input->post('vrooms');		
		$Data['datefrom']=$datefrom;
		$Data['dateto']=$dateto;
		$Data['searchdata']=$searchdata;
		$Data['v_data_hotel']= $this->PPmo->getHotelDetails($searchdata);	
		$datefrom=date("Y-m-d", strtotime($datefrom));
		$dateto=date("Y-m-d", strtotime($dateto));
		//echo '~'.$datefrom . '~' . $dateto ;	
		$Data['v_data_rooms']= $this->PPmo->getRoomsList($searchdata,$datefrom,$dateto);
        $Data['masters']="";        
        $this->loadView('public/public_page_rooms',$Data);
	} 


	public function bookRoom()
	{
		$Err=0; $ErrMsg=' ';$data['Success']='0';$ErrCode = '';$ErrTab = '';  
		if(isset($this->session->userdata['mysession']['client_id']))
		{      
			$user_id = $this->session->userdata['mysession']['client_id'];  				
		}
		else
		{	$user_id = 0;	}

        If($user_id==0){$Err=1; $ErrCode.='7,'; $ErrMsg= ' Please login/Register as guest to book room.';}
		$room_id=$this->input->post('room_id');
		$hotel_id=$this->input->post('hotel_id');
		$from_date=$this->input->post('vdatefrom');
		$to_date=$this->input->post('vdateto');


        if($Err==0)
        {
			$result=$this->PPmo->bookRoom($room_id,$hotel_id,$from_date,$to_date);
			if($result==1)
			{
				$data['msg']='Successfully Generated'  ; 
				$data['Success']='1';
			}
			else
			{
				$data['msg']='Error'  ; 
				$data['Success']='0';
			}
        }
        else
        {
            $data['msg']=$ErrMsg;
        }
        $data['ErrCode']=$ErrCode; 
		echo json_encode($data);
	} 

	function loadView($view,$data)
	{
	 	$this->load->view('public/public_header');	 	
		$this->load->view($view,$data);
		$this->load->view('public/public_footer');
	}
}
