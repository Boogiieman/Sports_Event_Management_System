<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
    function __construct()
    {
		parent::__construct();
		$this->load->database();
		date_default_timezone_set( 'Asia/Kolkata' ); 
		$this->load->model("admin_model","admo");
		$this->load->model("public_page_model","PPmo");
    }

	public function index()
	{
		$this->managehotels();
    } 
    
	public function login()
	{		
        $Data['masters']="";        
        $this->loadViewLogin('admin/login',$Data);
	} 
	public function forgotpassword()
	{		
        $Data['masters']="";        
        $this->loadView('admin/login',$Data);
	}
	
	public function managehotels()
	{		
		$Data['v_data']= $this->PPmo->getHotelList('');
        $Data['masters']="";        
        $this->loadView('admin/hotels_list',$Data);
	}
	public function managerooms()
	{		
		$Data['v_data']= $this->PPmo->getRoomsListFull('');
        $Data['masters']="";        
        $this->loadView('admin/rooms_list',$Data);
	}
	public function manageavailability()
	{		
        $Data['v_data']= $this->admo->getAvailabilityList('');
        $Data['masters']="";        
        $this->loadView('admin/availability_list',$Data); 
	}
	public function manageBookings()
	{		
        $Data['v_data']= $this->admo->getBookingList('');
        $Data['masters']="";        
        $this->loadView('admin/booking_list',$Data); 
	}
	public function manageGuests()
	{		
		$Data['v_data']= $this->PPmo->getGuestList('');
        $Data['masters']="";        
        $this->loadView('admin/guest_list',$Data);
	}
		
	public function logincheck()
	{
		$Err=0; $ErrMsg=' ';$data['Success']='0';$ErrCode = '';$ErrTab = '';   
			
		$email = $this->input->post('txtemail'); 
		$password = $this->input->post('txtpassword'); 
        
		If(empty($email)){$Err=1; $ErrCode.='7,'; $ErrMsg= ' EMail is missing';}
		If(empty($password)){$Err=1; $ErrCode.='7,'; $ErrMsg= ' Password is missing';}  

        if($Err==0)
        {       
			$rec=$this->admo->LoginCheck($email,$password);
			if($rec!="No")
			{      
				$row = $rec->row();
				$array= array(
					'user_id'		=> $row->id , 
					'user_name' 	=> $row->full_name , 
					'role_id' 	=> $row->role_id 
				);
                $this->session->set_userdata('adminsession', $array);
            	$data['msg']='Login Success'; 
				$data['Success']='1';
			}
			else
			{
				$data['msg']='Login Failed'; 
				$data['Success']='0';
			}
        }
        else
        {
            $data['msg']=$ErrMsg;
        }
        $data['ErrCode']=$ErrCode; 
		echo json_encode($data);
	}

	public function logout()
	{		
				$array= array(
					'user_id'	 , 
					'user_name'  , 
					'role_id'  
				);
                $this->session->unset_userdata('adminsession',  $array);
            	$this->login();
	}

	public function bookings()
	{		
        $Data['masters']="";        
        $this->loadView('guest/login',$Data);
	} 

	function loadView($view,$data)
	{
	 	$this->load->view('public/public_header');	 	
		$this->load->view($view,$data);
		$this->load->view('public/public_footer');
	}
	function loadViewLogin($view,$data)
	{
	 	$this->load->view('public/public_header_login');	 	
		$this->load->view($view,$data);
		$this->load->view('public/public_footer');
	}
}
