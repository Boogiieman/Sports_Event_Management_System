<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Hotel Booking System</title>

    <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet">

    
    <link href="<?php echo base_url(); ?>assets/css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/chosen/chosen.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/cropper/cropper.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/switchery/switchery.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/nouslider/jquery.nouislider.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/datapicker/datepicker3.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/ionRangeSlider/ion.rangeSlider.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/css/plugins/ionRangeSlider/ion.rangeSlider.skinFlat.css" rel="stylesheet">




    <!-- Mainly scripts -->
    <script src="<?php echo base_url(); ?>assets/js/jquery-2.1.1.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="<?php echo base_url(); ?>assets/js/inspinia.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/pace/pace.min.js"></script>

    <!-- Flot -->
    <script src="<?php echo base_url(); ?>assets/js/plugins/flot/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/flot/jquery.flot.resize.js"></script>

    <!-- ChartJS-->
    <script src="<?php echo base_url(); ?>assets/js/plugins/chartJs/Chart.min.js"></script>

    <!-- Peity -->
    <script src="<?php echo base_url(); ?>assets/js/plugins/peity/jquery.peity.min.js"></script>
    <!-- Peity demo 
    <script src="<?php echo base_url(); ?>assets/js/demo/peity-demo.js"></script>-->
    
    <script src="<?php echo base_url(); ?>assets/js/plugins/chosen/chosen.jquery.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/jsKnob/jquery.knob.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/jasny/jasny-bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/datapicker/bootstrap-datepicker.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/nouslider/jquery.nouislider.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/switchery/switchery.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/ionRangeSlider/ion.rangeSlider.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/iCheck/icheck.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/plugins/cropper/cropper.min.js"></script>


</head>

<body class="top-navigation">

    <div id="wrapper">
        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom white-bg">
        <nav class="navbar navbar-static-top" role="navigation">
            <div class="navbar-header">
                <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                    <i class="fa fa-reorder"></i>
                </button>
                <a href="<?php echo base_url(); ?>index.php/public_page/index" class="navbar-brand">Hotel Booking System</a>
            </div>
            <div class="navbar-collapse collapse" id="navbar">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <!--<a aria-expanded="false" role="button" href="layouts.html"> Back to main Layout page</a>-->
                        
                    </li>
                    <li class="dropdown">
                        <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"> Hotels <span class="caret"></span></a>
                        <ul role="menu" class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>index.php/public_page/hotels">Location wise</a></li>
                        </ul>
                    </li>
                    
                    <li class="dropdown">
                        <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"> Book Online <span class="caret"></span></a>
                        <ul role="menu" class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>index.php/guest/login">Client Login/Register</a></li>
							<li><a href="<?php echo base_url(); ?>index.php/guest/bookings">Client Bookings</a></li>
                        </ul>
                    </li>
                    <?php if(isset($this->session->userdata['mysession']['user_name'])){  ?>
                    <li class="dropdown">
                        <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"><?php  echo $this->session->userdata['mysession']['user_name']; ?><span class="caret"></span></a>                        
                        <ul role="menu" class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>index.php/guest/logout">Logout</a></li>
                        </ul>
                    </li>
                    <?php } ?>
                    <?php if(isset($this->session->userdata['adminsession']['user_id'])){  ?>
                    <li class="dropdown">
                        <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"><?php  echo $this->session->userdata['adminsession']['user_name']; ?><span class="caret"></span></a>                        
                        <ul role="menu" class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>index.php/admin/managehotels">Manage Hotels</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/admin/managerooms">Manage Rooms</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/admin/manageavailability">Manage Availability/Rate</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/admin/manageBookings">Manage Bookings</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/admin/manageGuests">Registered Users</a></li>
                        </ul>
                    </li>
                    <?php } ?>
                </ul>

                <ul class="nav navbar-top-links navbar-right">
                    <li>
                        <?php if(isset($this->session->userdata['adminsession']['user_id'])){  ?>
                                <a href="<?php echo base_url(); ?>index.php/admin/logout"><i class="fa fa-sign-out"></i> Hotel Log out</a>
                        <?php } else { ?>
                                <a href="<?php echo base_url(); ?>index.php/admin/login"><i class="fa fa-sign-out"></i> Hotel Log In</a>
                        <?php } ?>
                    </li>
                </ul>
            </div>
        </nav>
        </div>
        