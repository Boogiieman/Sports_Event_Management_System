
        <div class="wrapper wrapper-content">
            <div class="container">
            

                <div class="row">

                    <div class="col-lg-12">
                        <div class="ibox float-e-margins">
                            <div class="ibox-title">
                                <h5>List of Guest users</h5>
                                <div class="ibox-tools">
                                    <a class="collapse-link">
                                        <i class="fa fa-chevron-up"></i>
                                    </a>
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                        <i class="fa fa-wrench"></i>
                                    </a>
                                    
                                    <a class="close-link">
                                        <i class="fa fa-times"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="ibox-content">
                                <div class="row">
                                    <div class="col-sm-9 m-b-xs">
                                        <div data-toggle="buttons" class="btn-group">
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <!--<div class="input-group"><input type="text" placeholder="Search" class="input-sm form-control"> <span class="input-group-btn">
                                        <button type="button" class="btn btn-sm btn-primary"> Go!</button> </span></div>-->
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                        <tr>

                                            <th>#</th>
                                            <th>Name of User </th>
                                            <th>Contact </th>
                                            <th>EMail </th>
                                            <th>Created Date </th>
                                            <th>Status </th>
                                            <th>Action </th>
                                        </tr>
                                        </thead>
                                        <tbody>
<?php
	if($v_data!= "No")
    {
        $loop = 0;
    	foreach ($v_data->result() as $r)
     	{ 
     	    $loop = $loop + 1;
?>
                                        <tr>
                                            <td><?php echo $r->client_id; ?></td>
                                            <td><?php echo $r->full_name; ?></td>
                                            <td><?php echo $r->mobile_number; ?></td>
                                            <td><?php echo $r->email_id; ?></td>
                                            <td><?php echo $r->created_date; ?></td>
                                            <td><?php echo $r->status_id; ?></td>
                                            <td><div class="clearfix">
                                                <a class="btn btn-xs btn-info" onclick="DeletePage(<?php echo $r->client_id; ?>);"> <i class="fa fa-close"></i></a>
                                            </div></td>
                                        </tr>
<?php
        }
    } 
?>                                     
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>
        